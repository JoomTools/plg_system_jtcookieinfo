# plg_system_jtcookieinfo
Displays a pop-up window with information about the use of cookies.